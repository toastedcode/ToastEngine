package gameEngine;

import java.util.HashSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EventManager
{
   // **************************************************************************
   //                          Public Operations
   // **************************************************************************
   
   public static void initialize()
   {
      eventRegister = new HashMap<String, HashSet<String>>();
   }   
   
   
   public static void registerSpriteForEvent(
      String spriteId,
      String eventId)
   {
      // If we haven't registered any Sprites for this event, create the
      // Sprite set.
      if (eventRegister.containsKey(eventId) == false)
      {
         eventRegister.put(eventId, new HashSet<String>());
      }
      
      // Get the set of Sprites registered for this event.
      HashSet<String> registeredSprites = eventRegister.get(eventId);
      
      // Check for duplicate registrations.
      if (registeredSprites.contains(spriteId) == true)
      {
         logger.log(
            Level.WARNING, 
            String.format("Sprite [%s] is already registered for event id [%s].", 
               spriteId,
               eventId));
      }
      else
      {
         registeredSprites.add(spriteId);
         
         logger.log(
               Level.INFO, 
               String.format("Sprite [%s] registered for event id [%s].", 
                  spriteId,
                  eventId));
      }

   }
   
   
   public static void unregisterSprite(
      String spriteId)
   {
   }   
   
   
   public static void broadcastEvent(
      Event event)
   {
      String spriteId = null;
      Sprite sprite = null;
      
      if (eventRegister.containsKey(event.getEventId()) == true)
      {
         HashSet<String> registeredSprites = eventRegister.get(event.getEventId());
         
         Iterator<String> it = registeredSprites.iterator();
         while(it.hasNext())
         {
            spriteId = it.next();
            sprite = SpriteManager.getSprite(spriteId);
            if (sprite == null)
            {
               logger.log(
                     Level.WARNING, 
                     String.format("Invalid sprite id [%s] found in event register for event id [%s].", 
                        spriteId,
                        event.getEventId()));               
            }
            else
            {
               sprite.queueEvent(event);
            }
         }         
      }
      
   }
   
   
   public static void sendEvent(
      Event event,
      String spriteId)
   {
      Sprite sprite = SpriteManager.getSprite(spriteId);
      if (sprite == null)
      {
         logger.log(
               Level.WARNING, 
               String.format("Invalid sprite id [%s] specified.", 
                  spriteId,
                  event.getEventId()));               
      }
      else
      {
         sprite.queueEvent(event);
      }
      
   }

   
   public static void freeEventRegister()
   {
      eventRegister.clear();
   }
   
   // **************************************************************************
   //                          Private Attributes
   // **************************************************************************
   
   private final static Logger logger = Logger.getLogger(EventManager.class.getName());      
   
   
   // A structure mapping Event ids to lists of Sprite ids.
   // This dictates which Sprites will receive broadcast events. 
   private static HashMap<String, HashSet<String>> eventRegister;
}
