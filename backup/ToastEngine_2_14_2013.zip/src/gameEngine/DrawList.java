package gameEngine;

import java.util.Collections;
import java.util.Comparator;

public class DrawList extends LockableList<Sprite>
{

   // **************************************************************************
   //                          Public Operations
   // **************************************************************************
   
   // Constructor
   public DrawList()
   {
      super();
   }

   
   // Overide the add() operation to keep this list of Sprites ordered (descending) by z-order.
   public boolean add(
      Sprite sprite)
   {
      boolean returnStatus = super.add(sprite);
      
      if (isLocked() == false)
      {
         Collections.sort(this, Z_ORDER_COMPARATOR);         
      }
      
      return (returnStatus);
   }
  
   // **************************************************************************
   //                          Private Attributes
   // **************************************************************************

   static final Comparator<Sprite> Z_ORDER_COMPARATOR = new Comparator<Sprite>()
   {
      public int compare(Sprite sprite1, Sprite sprite2)
      {
         return(((sprite1.getZOrder() > sprite2.getZOrder()) ? -1 :
                 (sprite1.getZOrder() == sprite2.getZOrder()) ? 0 : 1));
      }
   };
   
}