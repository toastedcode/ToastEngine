package gameEngine;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import simpleXml.XmlNode;

public class SfxManager
{
   // **************************************************************************
   //                             Public Operations
   // **************************************************************************
   
   public static SfxManager getInstance()
   {
      if (instance == null)
      {
         instance = new SfxManager();
      }
      
      return (instance);
   }

   
   public Sfx createSfx(
      XmlNode node)
   {
      Sfx sfx = new Sfx(node);
      
      String sfxId = sfx.getSfxId();
      if (sfxId == null)
      {
         logger.log(Level.WARNING, String.format("No id specified for Sfx."));
         sfx = null;
      }
      else if (sfxMap.containsKey(sfxId) == true)
      {
         logger.log(Level.WARNING, String.format("Duplicate Sfx id [%s] found.", sfxId)); 
         sfx = null;
      }
      else
      {
         sfxMap.put(sfxId, sfx);         
      }
      
      return (sfx);
   }     

   
   public Sfx getSfx(
      String sfxId)
   {
      Sfx sfx = null;
      
      if (sfxMap.containsKey(sfxId) == false)
      {
         logger.log(Level.WARNING, 
                    String.format("Sfx [%s] cannot be found.", sfxId));
      }
      else
      {
         sfx = sfxMap.get(sfxId);
      }
      
      return (sfx);
   }
   
   
   public void playSfx(
      String sfxId)
   {
      Sfx sfx = getSfx(sfxId);
      if (sfx != null)
      {
         SfxPlayer sfxPlayer = new SfxPlayer(getSfx(sfxId));
         sfxPlayer.start();
      }
   }   
   
   
   public void freeSfx()
   {
      sfxMap.clear();
   }
   
   
   public static void save(
      XmlNode node)
   {
      // Loop through the Sfx map and save each entry.
      for (Map.Entry<String, Sfx> entry : sfxMap.entrySet())
      {
         entry.getValue().save(node);
      }
   }      
   
   // **************************************************************************
   //                         Private Internal Classes
   // **************************************************************************
   
   class SfxPlayer extends Thread
   {
      public SfxPlayer(
         Sfx initSfx)
      {
         // TODO: Attempt a deep-copy of this so we end up with two different Clip objects.
         sfx = initSfx;  
      }
      
      public void run()
      {
         sfx.play();
         sfx.reset();
      }
      
      private Sfx sfx;
   }
   
   // **************************************************************************
   //                           Private Operations
   // **************************************************************************
   
   // Constructor
   private SfxManager()
   {
      initialize();
   }
   
   
   // This operation creates the internal structures used in storing Animation.
   private void initialize()
   {
      sfxMap = new HashMap<String, Sfx>();
   }   
   
   // **************************************************************************
   //                           Private Attributes
   // **************************************************************************
   
   private final static Logger logger = 
      Logger.getLogger(AnimationManager.class.getName());
   
   // An instance of the SfxManager class, used in implementing the Singleton pattern.
   private static SfxManager instance;
   
   // A map of Sfx objects, used to quickly retrieve a Sfx its id.
   private static Map<String, Sfx> sfxMap;   
}