package gameEngine;

import java.net.URL;
import java.awt.Point;
import java.awt.Dimension;
import java.awt.geom.Path2D;
import java.awt.Rectangle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathConstants;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;

public class XmlInterface
{
   public static Document loadXmlDocument(
      String fileName)
   {
      Document document = null;
      DocumentBuilder db = null;
      URL url = null;
      
      try
      {
         url = ResourceManager.class.getResource(fileName);
      }
      catch (Exception e)
      {
         logger.log(Level.WARNING, "Exception!  Failed to get URL for XML document.");     
      }
      
      if (url == null)
      {
         logger.log(Level.WARNING, "Failed to get URL for XML document.");
      }
      else
      {
         DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
         try
         {
            db = dbf.newDocumentBuilder();
         }
         catch (Exception e)
         {
            logger.log(Level.WARNING, "Exception!  Failed to get a new DocumentBuilder object.");    
         }
         
         if (db == null)
         {
            logger.log(Level.WARNING, "Failed to get a new DocumentBuilder object.");            
         }
         else
         {
            try
            {
               document = db.parse(url.toURI().toString());
            }
            catch  (Exception e)
            {
               logger.log(Level.WARNING, "Exception!  Failed to parse the XML document.");  
            }
         }
         
      }
      
      return (document);
   }
   
   public static boolean hasAttribute(
         Node node, 
         String attributeName)
   {
      NamedNodeMap attributes = node.getAttributes();
      return ((attributes != null) &&
              (attributes.getNamedItem(attributeName) != null));
   }   
   
   
   public static String getAttribute(
         Node node, 
         String attributeName)
   {
      String value = null;
      
      if (hasAttribute(node, attributeName) == true)
      {
         value = node.getAttributes().getNamedItem(attributeName).getNodeValue();
      }
      
      return (value);
   }
   
   
   public static boolean getBoolAttribute(
         Node node, 
         String attributeName)
   {
      boolean value = false;
      
      if (hasAttribute(node, attributeName) == true)
      {
         value = Boolean.parseBoolean(getAttribute(node, attributeName));
      }
      
      return (value);
   }   
   
   
   public static String getValue(
      Node node)
   {
      String value = null;
      
      if (node != null)
      {
         value = node.getTextContent();
      }
         
      return (value);
   }   

   
   public static Node getRootNode(
      Document document)
   {
      return (document.getDocumentElement());
   }
   
   
   public static boolean hasChildNode(
      Node parentNode,
      String nodeName)
   {
      boolean returnStatus = false;
      
      if (parentNode.getNodeType() == Node.ELEMENT_NODE)
      {
         // Cast to an Element and retrieve all child nodes with the specified name.
         Element element = (Element)parentNode;
         NodeList childNodes = element.getElementsByTagName(nodeName);
         
         returnStatus = (childNodes.getLength() == 1);
      }
      
      return (returnStatus);
   }   
   
   
   public static Node getChildNode(
      Node parentNode,
      String nodeName)
   {
      Node childNode = null;
      
      if (parentNode.getNodeType() != Node.ELEMENT_NODE)
      {
         logger.log(
               Level.WARNING, 
               "Invalid call on a non-Element node.");           
      }
      else
      {
         // Cast to an Element and retrieve all child nodes with the specified name.
         Element element = (Element)parentNode;
         NodeList childNodes = element.getElementsByTagName(nodeName);
         
         // We're only expecting to find one.
         if (childNodes.getLength() != 1)
         {
            logger.log(
                  Level.WARNING, 
                  String.format(
                     "Expected one \"%s\" node.  Found %d.", 
                     nodeName,
                     childNodes.getLength()));  
         }
         else
         {
            childNode = childNodes.item(0);
         }
      }  // end if (parentNode.getNodeType() != Node.ELEMENT_NODE)
      
      return (childNode);
   }
   
   
   public static NodeList getChildNodes(
      Node parentNode,
      String nodeName)
   {
      NodeList childNodes = null;
      
      if (parentNode.getNodeType() != Node.ELEMENT_NODE)
      {
         logger.log(
               Level.WARNING, 
               "Invalid call on a non-Element node.");           
      }
      else
      {
         // Cast to an Element and retrieve all child nodes with the specified name.
         Element element = (Element)parentNode;
         childNodes = element.getElementsByTagName(nodeName);
         
      }  // end if (parentNode.getNodeType() != Node.ELEMENT_NODE)
      
      return (childNodes);
   }
   
   
   public static NodeList getNodes(
      Node startingNode,
      String xPathString)
   {
      NodeList matchingNodes = null;
      
      XPathFactory xPathFactory = XPathFactory.newInstance();
      XPath xPath = xPathFactory.newXPath();
      XPathExpression xPathExpression = null;
      
      try
      {
         xPathExpression = xPath.compile(xPathString);
      }
      catch (Exception e)
      {
         logger.log(Level.WARNING,                   
                    String.format(
                    "Exception!  Failed to compile xPath expression: %s", 
                    xPathString));  
      }
      
      try
      {
         matchingNodes = 
            (NodeList)xPathExpression.evaluate(startingNode, XPathConstants.NODESET);         
      }
      catch (Exception e)
      {
         logger.log(Level.WARNING,                   
                    String.format(
                    "Exception!  Failed to evaluate xPath expression: %s", 
                    xPathString));  
      }
      
      return (matchingNodes);
   }

   
   public static String getId(
      Node node)
   {
      return (getAttribute(node, "id"));
   }
   
   
   public static boolean hasProperty(
      Node node,
      String propertyName)
   {
      return (hasChildNode(node, propertyName));
   }
   
   
   public static String getStringProperty(
      Node node,
      String propertyName)
   {
      String propertyValue = null;
      if (hasProperty(node, propertyName) == true)
      {
         propertyValue = getValue(getChildNode(node, propertyName));
      }
      
      return (propertyValue);
   }   
   
   
   public static int getIntProperty(
         Node node,
         String propertyName)
   {
      int propertyValue = 0;
      if (hasProperty(node, propertyName) == true)
      {
         propertyValue = Integer.parseInt(getValue(getChildNode(node, propertyName)));
      }
      
      return (propertyValue);
   }   
   
   
   public static double getDoubleProperty(
         Node node,
         String propertyName)
   {
      double propertyValue = 0;
      if (hasProperty(node, propertyName) == true)
      {
         propertyValue = java.lang.Double.parseDouble(getValue(getChildNode(node, propertyName)));
      }
      
      return (propertyValue);
   }      
   
   
   public static boolean getBoolProperty(
         Node node,
         String propertyName)
   {
      boolean propertyValue = false;
      if (hasProperty(node, propertyName) == true)
      {
         propertyValue = Boolean.parseBoolean(getValue(getChildNode(node, propertyName)));
      }
      
      return (propertyValue);
   }
   
   
   public static Character getCharacterProperty(
         Node node,
         String propertyName)
   {
      Character propertyValue = new Character('\u0000');
      if (hasProperty(node, propertyName) == true)
      {
         propertyValue = getValue(getChildNode(node, propertyName)).charAt(0);
      }
      
      return (propertyValue);
   }   
   
   
   public static Dimension getDimensionProperty(
      Node node,
      String propertyName)
   {
      Dimension propertyValue = new Dimension(0, 0);
      Node dimensionNode = null;
      
      if (hasProperty(node, propertyName) == true)
      {
         dimensionNode = getChildNode(node, propertyName);
         if (hasProperty(dimensionNode, "height") == true)
         {
            propertyValue.height = getIntProperty(dimensionNode, "height");
         }
         if (hasProperty(dimensionNode, "width") == true)
         {
            propertyValue.width = getIntProperty(dimensionNode, "width");
         }
      }
      
      return (propertyValue);
   }
   
   
   public static Point getPointProperty(
      Node node,
      String propertyName)
   {
      Point propertyValue = new Point(0, 0);
      Node pointNode = null;
      
      if (hasProperty(node, propertyName) == true)
      {
         pointNode = getChildNode(node, propertyName);
         if (hasProperty(pointNode, "x") == true)
         {
            propertyValue.x = getIntProperty(pointNode, "x");
         }
         if (hasProperty(pointNode, "y") == true)
         {
            propertyValue.y = getIntProperty(pointNode, "y");
         }
      }
      
      return (propertyValue);
   }
   
   
   public static Vector2D getVectorProperty(
      Node node,
      String propertyName)
   {
      Vector2D propertyValue = new Vector2D(0, 0);
      Node vectorNode = null;
      
      if (hasProperty(node, propertyName) == true)
      {
         vectorNode = getChildNode(node, propertyName);
         if (hasProperty(vectorNode, "x") == true)
         {
            propertyValue.x = getDoubleProperty(vectorNode, "x");
         }
         if (hasProperty(vectorNode, "y") == true)
         {
            propertyValue.y = getDoubleProperty(vectorNode, "y");
         }
      }
      
      return (propertyValue);
   }       
   
   
   public static Rectangle getRectangleProperty(
      Node node,
      String propertyName)
   {
      Rectangle propertyValue = new Rectangle();
      Node rectangleNode = null;
      
      if (hasProperty(node, propertyName) == true)
      {
         rectangleNode = getChildNode(node, propertyName);
         if (hasProperty(rectangleNode, "x") == true)
         {
            propertyValue.x = getIntProperty(rectangleNode, "x");
         }
         if (hasProperty(rectangleNode, "y") == true)
         {
            propertyValue.y = getIntProperty(rectangleNode, "y");
         }
         if (hasProperty(rectangleNode, "height") == true)
         {
            propertyValue.height = getIntProperty(rectangleNode, "height");
         }
         if (hasProperty(rectangleNode, "width") == true)
         {
            propertyValue.width = getIntProperty(rectangleNode, "width");
         }         
      }
      
      return (propertyValue);
   }
   
   
   public static Path2D getPolygonProperty(
      Node node,
      String propertyName)
   {
      Path2D propertyValue = null;
      Node polygonNode = null;
      NodeList pointNodes = null;
      Point point = new Point(); 
      
      if (hasProperty(node, propertyName) == true)
      {
         polygonNode = getChildNode(node, propertyName);
         
         pointNodes = getNodes(polygonNode, "./point");
         if (pointNodes.getLength() > 2)
         {
            // Create the polygon object.
            propertyValue = new Path2D.Double();
            
            // Loop through the point nodes.
            for (int i = 0; i < pointNodes.getLength(); i++)
            {
               polygonNode = pointNodes.item(i);
               
               // Construct the point.
               if (hasProperty(polygonNode, "x") == true)
               {
                  point.x = getIntProperty(polygonNode, "x");
               }
               if (hasProperty(polygonNode, "y") == true)
               {
                  point.y = getIntProperty(polygonNode, "y");
               }
               
               // Add to the polygon.
               if (i == 0)
               {
                  propertyValue.moveTo((double)point.x, (double)point.y);
               }
               else
               {
                  propertyValue.lineTo((double)point.x, (double)point.y);                     
               }
            }  // end for (int i = 0; i < pointNodes.getLength(); i++)
            
            // Close the polygon.
            if ((hasAttribute(polygonNode, "isClosed") == true) &&
                (getBoolAttribute(polygonNode, "isClosed") == true))
            {
               propertyValue.closePath();
            }
            
         }  // end if (pointNodes.getLength() > 2)
      }  // end if (hasProperty(node, propertyName) == true)
      
      return (propertyValue);
   }
   
   private final static Logger logger = Logger.getLogger(XmlInterface.class.getName());   
   
}
