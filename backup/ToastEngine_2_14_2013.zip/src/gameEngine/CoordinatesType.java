package gameEngine;

public enum CoordinatesType
{
   WORLD,
   SCREEN,
   OFFSET
}
