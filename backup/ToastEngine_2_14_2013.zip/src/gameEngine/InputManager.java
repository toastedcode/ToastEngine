package gameEngine;

import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.Point;
import java.util.HashMap;
import java.util.Map;

public class InputManager
{
   public static void initialize()
   {
      mousePosition = new Point(0, 0);
   }   
   
   
   public static void handleKeyPressed(
      KeyEvent e)
   {
      // Populate the map, once.
      if (pressedKeyMap == null)
      {
         pressedKeyMap = new HashMap<Integer, String>();
         pressedKeyMap.put(KeyEvent.VK_RIGHT, "eventKP_RIGHT");
         pressedKeyMap.put(KeyEvent.VK_LEFT,  "eventKP_LEFT");
         pressedKeyMap.put(KeyEvent.VK_UP,    "eventKP_UP");
         pressedKeyMap.put(KeyEvent.VK_DOWN,  "eventKP_DOWN");
         pressedKeyMap.put(KeyEvent.VK_SPACE, "eventKP_SPACE");
         pressedKeyMap.put(KeyEvent.VK_V,     "eventKP_V");
         pressedKeyMap.put(KeyEvent.VK_D,     "eventKP_D");
         pressedKeyMap.put(KeyEvent.VK_Z,     "eventKP_Z");
         pressedKeyMap.put(KeyEvent.VK_X,     "eventKP_X");
         pressedKeyMap.put(KeyEvent.VK_C,     "eventKP_C");
         pressedKeyMap.put(KeyEvent.VK_S,     "eventKP_S");
      }
      
      if (pressedKeyMap.containsKey(e.getKeyCode()) == true)
      {
         EventManager.broadcastEvent(new Event(pressedKeyMap.get(e.getKeyCode())));
      }
      
      // Test
      if (e.getKeyCode() == KeyEvent.VK_S)
      {
         LevelManager.getInstance().getCurrentLevel().save("saveGame.xml");
      }
   }
   
   
   public static void handleKeyReleased(
      KeyEvent e)
   {
      // Populate the map, once.
      if (releasedKeyMap == null)
      {
         releasedKeyMap = new HashMap<Integer, String>();
         releasedKeyMap.put(KeyEvent.VK_RIGHT, "eventKR_RIGHT");
         releasedKeyMap.put(KeyEvent.VK_LEFT,  "eventKR_LEFT");
         releasedKeyMap.put(KeyEvent.VK_UP,    "eventKR_UP");
         releasedKeyMap.put(KeyEvent.VK_DOWN,  "eventKR_DOWN");
         releasedKeyMap.put(KeyEvent.VK_SPACE, "eventKR_SPACE");
         releasedKeyMap.put(KeyEvent.VK_V,     "eventKR_V");
         releasedKeyMap.put(KeyEvent.VK_D,     "eventKR_D");
         releasedKeyMap.put(KeyEvent.VK_Z,     "eventKR_Z");
         releasedKeyMap.put(KeyEvent.VK_X,     "eventKR_X");
         releasedKeyMap.put(KeyEvent.VK_C,     "eventKR_C");
         releasedKeyMap.put(KeyEvent.VK_C,     "eventKR_S");
      }
      
      if (releasedKeyMap.containsKey(e.getKeyCode()) == true)
      {
         EventManager.broadcastEvent(new Event(releasedKeyMap.get(e.getKeyCode())));         
      }
   }
   
   
   public static void handleMousePressed(
      MouseEvent e)
   {
      mousePosition.x = e.getX();
      mousePosition.y = e.getY();
      EventManager.broadcastEvent(new Event("eventMOUSE_PRESSED"));
      
   }
      
      
   public static void handleMouseReleased(
      MouseEvent e)
   {
      mousePosition.x = e.getX();
      mousePosition.y = e.getY();
      EventManager.broadcastEvent(new Event("eventMOUSE_RELEASED"));      
   }
   
   
   public static void handleMouseMoved(
      MouseEvent e)         
   {
      mousePosition.x = e.getX();
      mousePosition.y = e.getY();
   }   
   
   
   public static Point getMousePosition()
   {
      return (mousePosition);
   }

   
   public static Point getMouseWorldPosition()
   {
      return (ViewManager.getWorldPosition(mousePosition));
   }
   
   
   // **************************************************************************
   //                          Private Attributes
   // **************************************************************************
   
   static Map<Integer, String> pressedKeyMap;
   
   static Map<Integer, String> releasedKeyMap;
   
   static Point mousePosition;
   
}